
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'taotao',
  applicationName: 'serverless',
  appUid: 'c5WxvJqSZ7wfSFRFcm',
  orgUid: 'bb32f148-b699-4167-8c6a-666b3cb51aa0',
  deploymentUid: 'ab09a252-f71c-4e95-92eb-c467621b9d15',
  serviceName: 'serverless',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-dev-app', timeout: 6 };

try {
  const userHandler = require('./controllers/itemController.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getAllCategory, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}